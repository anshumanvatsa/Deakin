const About = () => {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-background to-muted/30">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-quantum bg-clip-text text-transparent mb-4">
            About the Conference
          </h2>
          <div className="w-24 h-1 bg-gradient-quantum mx-auto rounded-full"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Vision Card */}
          <div className="group relative bg-card rounded-3xl p-8 shadow-card-hover border border-border hover:shadow-quantum transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-card rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div className="relative z-10">
              <div className="w-16 h-16 bg-gradient-quantum rounded-2xl flex items-center justify-center mb-6">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                </svg>
              </div>
              <h3 className="text-2xl font-semibold mb-4 text-foreground">Our Vision</h3>
              <p className="text-muted-foreground leading-relaxed">
                ICRTAC'25 envisions uniting Indian and Australian research excellence to advance quantum computing, 
                artificial intelligence, and sustainable technologies. By fostering interdisciplinary collaboration 
                between VIT Chennai and Deakin University, we aim to create a global platform for breakthrough 
                innovations that shape the future of technology.
              </p>
            </div>
          </div>

          {/* Mission Card */}
          <div className="group relative bg-card rounded-3xl p-8 shadow-card-hover border border-border hover:shadow-quantum transition-all duration-300">
            <div className="absolute inset-0 bg-gradient-card rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
            <div className="relative z-10">
              <div className="w-16 h-16 bg-gradient-quantum rounded-2xl flex items-center justify-center mb-6">
                <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h3 className="text-2xl font-semibold mb-4 text-foreground">Our Mission</h3>
              <p className="text-muted-foreground leading-relaxed">
                To create an international forum where researchers, academicians, and industry experts converge to 
                share cutting-edge research in quantum technologies. We are committed to promoting cross-continental 
                collaboration, accelerating innovation, and addressing global challenges through quantum solutions 
                with real-world impact.
              </p>
            </div>
          </div>
        </div>

        {/* Key Highlights */}
        <div className="mt-16 grid md:grid-cols-3 gap-6">
          {[
            { number: "500+", label: "Expected Participants" },
            { number: "50+", label: "Research Papers" },
            { number: "2", label: "Continents United" }
          ].map((stat, index) => (
            <div 
              key={index} 
              className="text-center p-6 bg-gradient-card rounded-2xl border border-border animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <div className="text-4xl font-bold bg-gradient-quantum bg-clip-text text-transparent mb-2">
                {stat.number}
              </div>
              <div className="text-muted-foreground font-medium">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default About;
