import { User } from "lucide-react";

const organizers = [
  {
    name: "Dr. [Name TBA]",
    title: "Chancellor",
    organization: "VIT Chennai",
    role: "Chief Patron"
  },
  {
    name: "Dr. [Name TBA]",
    title: "Vice-Chancellor",
    organization: "Deakin University",
    role: "Chief Patron"
  },
  {
    name: "Dr. [Name TBA]",
    title: "Director",
    organization: "VIT Chennai",
    role: "Conference Chair"
  },
  {
    name: "Dr. [Name TBA]",
    title: "Director",
    organization: "Deakin University",
    role: "Conference Co-Chair"
  }
];

const Organizers = () => {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-muted/30 to-background">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-quantum bg-clip-text text-transparent mb-4">
            Organizers & Patrons
          </h2>
          <p className="text-muted-foreground text-lg">
            Leadership from VIT Chennai and Deakin University
          </p>
          <div className="w-24 h-1 bg-gradient-quantum mx-auto rounded-full mt-4"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {organizers.map((organizer, index) => (
            <div
              key={index}
              className="group relative bg-card rounded-3xl p-8 shadow-card-hover border border-border hover:shadow-quantum transition-all duration-300 hover:-translate-y-1 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Gradient overlay */}
              <div className="absolute inset-0 bg-gradient-card rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              
              <div className="relative z-10 flex items-start gap-6">
                {/* Avatar placeholder */}
                <div className="w-24 h-24 bg-gradient-quantum rounded-2xl flex items-center justify-center flex-shrink-0 group-hover:scale-105 transition-transform duration-300">
                  <User className="w-12 h-12 text-white" />
                </div>

                {/* Info */}
                <div className="flex-1">
                  <div className="inline-block bg-primary/10 text-primary px-3 py-1 rounded-full text-xs font-semibold mb-3">
                    {organizer.role}
                  </div>
                  <h3 className="text-xl font-bold text-foreground mb-2">
                    {organizer.name}
                  </h3>
                  <p className="text-muted-foreground font-medium mb-1">
                    {organizer.title}
                  </p>
                  <p className="text-sm text-muted-foreground">
                    {organizer.organization}
                  </p>
                </div>
              </div>

              {/* Decorative corner */}
              <div className="absolute bottom-0 right-0 w-24 h-24 bg-gradient-quantum opacity-5 rounded-tl-full"></div>
            </div>
          ))}
        </div>

        {/* Committee Note */}
        <div className="mt-12 text-center bg-card rounded-2xl p-6 border border-border">
          <p className="text-muted-foreground">
            <span className="font-semibold text-foreground">Note:</span> Complete organizing committee details including 
            Technical Program Committee, Advisory Board, and International Committee will be announced soon.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Organizers;
