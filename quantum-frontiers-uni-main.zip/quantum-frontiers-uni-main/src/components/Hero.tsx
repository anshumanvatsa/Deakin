import { Button } from "@/components/ui/button";
import { Calendar, MapPin } from "lucide-react";
import heroImage from "@/assets/hero-quantum.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-hero opacity-90"></div>
      </div>

      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-float"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/20 rounded-full blur-3xl animate-float" style={{ animationDelay: '1s' }}></div>
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-20 text-center">
        {/* University Logos */}
        <div className="flex justify-center items-center gap-8 mb-8 flex-wrap">
          <div className="bg-white/10 backdrop-blur-glass border border-white/20 rounded-2xl px-8 py-4">
            <p className="text-white font-semibold text-lg">VIT Chennai</p>
          </div>
          <div className="text-white text-2xl font-light">×</div>
          <div className="bg-white/10 backdrop-blur-glass border border-white/20 rounded-2xl px-8 py-4">
            <p className="text-white font-semibold text-lg">Deakin University</p>
          </div>
        </div>

        {/* Main Title */}
        <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 animate-fade-in">
          ICRTAC'25
        </h1>
        
        <div className="max-w-4xl mx-auto mb-8">
          <h2 className="text-2xl md:text-3xl text-white/90 font-light mb-4 animate-fade-in" style={{ animationDelay: '0.2s' }}>
            International Conference on Recent Advances in
          </h2>
          <h2 className="text-3xl md:text-4xl font-semibold bg-gradient-quantum bg-clip-text text-transparent animate-fade-in" style={{ animationDelay: '0.3s' }}>
            Quantum Computing & Emerging Technologies
          </h2>
        </div>

        {/* Theme */}
        <p className="text-xl md:text-2xl text-white/80 italic mb-12 max-w-3xl mx-auto animate-fade-in" style={{ animationDelay: '0.4s' }}>
          "Quantum Frontiers – Bridging Research and Innovation Across Continents"
        </p>

        {/* Event Details */}
        <div className="flex flex-wrap justify-center gap-6 mb-12 animate-fade-in" style={{ animationDelay: '0.5s' }}>
          <div className="flex items-center gap-2 bg-white/10 backdrop-blur-glass border border-white/20 rounded-full px-6 py-3">
            <Calendar className="w-5 h-5 text-white" />
            <span className="text-white font-medium">June 2025 (Dates TBA)</span>
          </div>
          <div className="flex items-center gap-2 bg-white/10 backdrop-blur-glass border border-white/20 rounded-full px-6 py-3">
            <MapPin className="w-5 h-5 text-white" />
            <span className="text-white font-medium">VIT Chennai & Deakin University</span>
          </div>
        </div>

        {/* CTA Button */}
        <div className="animate-fade-in" style={{ animationDelay: '0.6s' }}>
          <Button 
            size="lg"
            className="bg-gradient-quantum hover:shadow-quantum transition-all duration-300 transform hover:scale-105 text-lg px-8 py-6 rounded-full font-semibold"
          >
            Register Now
          </Button>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-white/50 rounded-full flex justify-center">
            <div className="w-1 h-3 bg-white/50 rounded-full mt-2"></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
