import { Mail, Phone, MapPin, Building2 } from "lucide-react";

const contacts = [
  {
    institution: "VIT Chennai",
    location: "Chennai, Tamil Nadu, India",
    coordinators: [
      {
        name: "Dr. [Name TBA]",
        email: "icrtac2025@vit.ac.in",
        phone: "+91 [Number TBA]"
      }
    ]
  },
  {
    institution: "Deakin University",
    location: "Melbourne, Victoria, Australia",
    coordinators: [
      {
        name: "Dr. [Name TBA]",
        email: "icrtac2025@deakin.edu.au",
        phone: "+61 [Number TBA]"
      }
    ]
  }
];

const Contact = () => {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-background to-muted/30">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-quantum bg-clip-text text-transparent mb-4">
            Contact Us
          </h2>
          <p className="text-muted-foreground text-lg">
            Get in touch with our conference coordinators
          </p>
          <div className="w-24 h-1 bg-gradient-quantum mx-auto rounded-full mt-4"></div>
        </div>

        {/* Contact Cards */}
        <div className="grid md:grid-cols-2 gap-8 mb-12">
          {contacts.map((contact, index) => (
            <div
              key={index}
              className="bg-card rounded-3xl p-8 shadow-card-hover border border-border hover:shadow-quantum transition-all duration-300 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Institution Header */}
              <div className="flex items-center gap-4 mb-6 pb-6 border-b border-border">
                <div className="w-14 h-14 bg-gradient-quantum rounded-xl flex items-center justify-center">
                  <Building2 className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-foreground">{contact.institution}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <MapPin className="w-4 h-4 text-muted-foreground" />
                    <p className="text-sm text-muted-foreground">{contact.location}</p>
                  </div>
                </div>
              </div>

              {/* Coordinator Info */}
              {contact.coordinators.map((coordinator, coordIndex) => (
                <div key={coordIndex} className="space-y-4">
                  <div>
                    <p className="text-sm font-semibold text-primary mb-2">Conference Coordinator</p>
                    <p className="text-lg font-semibold text-foreground">{coordinator.name}</p>
                  </div>
                  
                  <div className="space-y-3">
                    <div className="flex items-center gap-3 group">
                      <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                        <Mail className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Email</p>
                        <a 
                          href={`mailto:${coordinator.email}`}
                          className="text-foreground hover:text-primary transition-colors font-medium"
                        >
                          {coordinator.email}
                        </a>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 group">
                      <div className="w-10 h-10 bg-secondary/10 rounded-lg flex items-center justify-center group-hover:bg-secondary/20 transition-colors">
                        <Phone className="w-5 h-5 text-secondary" />
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Phone</p>
                        <p className="text-foreground font-medium">{coordinator.phone}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* Map Section */}
        <div className="bg-card rounded-3xl p-8 shadow-card-hover border border-border">
          <h3 className="text-2xl font-bold text-foreground mb-6 text-center">
            Conference Locations
          </h3>
          
          <div className="grid md:grid-cols-2 gap-6">
            {/* VIT Chennai Map */}
            <div className="rounded-2xl overflow-hidden border border-border shadow-lg">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3890.2626826933676!2d80.15258631482108!3d12.840939790939568!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a52f712b82a78d9%3A0xfdb944a3aee53831!2sVIT%20Chennai!5e0!3m2!1sen!2sin!4v1234567890123!5m2!1sen!2sin"
                width="100%"
                height="300"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="VIT Chennai Location"
              ></iframe>
              <div className="bg-gradient-card p-4 border-t border-border">
                <p className="font-semibold text-foreground">VIT Chennai</p>
                <p className="text-sm text-muted-foreground">Chennai, India</p>
              </div>
            </div>

            {/* Deakin University Map */}
            <div className="rounded-2xl overflow-hidden border border-border shadow-lg">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.8385385572983!2d144.96305931531682!3d-37.81410797975171!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad65d4c2b349649%3A0xb6899234e561db11!2sDeakin%20University!5e0!3m2!1sen!2sau!4v1234567890123!5m2!1sen!2sau"
                width="100%"
                height="300"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Deakin University Location"
              ></iframe>
              <div className="bg-gradient-card p-4 border-t border-border">
                <p className="font-semibold text-foreground">Deakin University</p>
                <p className="text-sm text-muted-foreground">Melbourne, Australia</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
