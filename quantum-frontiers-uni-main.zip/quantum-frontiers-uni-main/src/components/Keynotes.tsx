import { Users } from "lucide-react";

const Keynotes = () => {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-muted/30 to-background">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-quantum bg-clip-text text-transparent mb-4">
            Keynote Speakers
          </h2>
          <p className="text-muted-foreground text-lg">
            World-renowned experts in quantum computing and emerging technologies
          </p>
          <div className="w-24 h-1 bg-gradient-quantum mx-auto rounded-full mt-4"></div>
        </div>

        {/* Coming Soon Card */}
        <div className="relative bg-card rounded-3xl p-16 shadow-card-hover border border-border text-center overflow-hidden">
          {/* Decorative elements */}
          <div className="absolute top-0 left-0 w-40 h-40 bg-gradient-quantum opacity-5 rounded-br-full"></div>
          <div className="absolute bottom-0 right-0 w-40 h-40 bg-gradient-quantum opacity-5 rounded-tl-full"></div>
          
          <div className="relative z-10">
            <div className="w-24 h-24 bg-gradient-quantum rounded-full flex items-center justify-center mx-auto mb-6 animate-float">
              <Users className="w-12 h-12 text-white" />
            </div>
            
            <h3 className="text-3xl font-bold text-foreground mb-4">
              Speakers Coming Soon
            </h3>
            
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto mb-8">
              We are in the process of confirming distinguished keynote speakers from leading research institutions 
              and industry pioneers in quantum computing, AI, and emerging technologies. Check back soon for announcements!
            </p>

            <div className="flex flex-wrap justify-center gap-4">
              <div className="bg-gradient-card px-6 py-3 rounded-full border border-border">
                <p className="text-sm font-semibold text-foreground">International Experts</p>
              </div>
              <div className="bg-gradient-card px-6 py-3 rounded-full border border-border">
                <p className="text-sm font-semibold text-foreground">Industry Leaders</p>
              </div>
              <div className="bg-gradient-card px-6 py-3 rounded-full border border-border">
                <p className="text-sm font-semibold text-foreground">Academic Pioneers</p>
              </div>
            </div>
          </div>
        </div>

        {/* Expected Speaker Categories */}
        <div className="mt-12 grid md:grid-cols-3 gap-6">
          {[
            {
              title: "Quantum Computing",
              description: "Experts in quantum algorithms and hardware"
            },
            {
              title: "Artificial Intelligence",
              description: "Leaders in AI and machine learning research"
            },
            {
              title: "Industry Applications",
              description: "Practitioners applying quantum solutions"
            }
          ].map((category, index) => (
            <div
              key={index}
              className="bg-card rounded-2xl p-6 border border-border text-center animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <h4 className="text-lg font-semibold text-foreground mb-2">{category.title}</h4>
              <p className="text-sm text-muted-foreground">{category.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Keynotes;
