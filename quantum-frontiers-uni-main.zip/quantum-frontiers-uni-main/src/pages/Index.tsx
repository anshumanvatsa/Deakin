import Hero from "@/components/Hero";
import About from "@/components/About";
import Tracks from "@/components/Tracks";
import Organizers from "@/components/Organizers";
import ImportantDates from "@/components/ImportantDates";
import Keynotes from "@/components/Keynotes";
import Publishing from "@/components/Publishing";
import Committee from "@/components/Committee";
import Auth from "@/components/Auth";
import Contact from "@/components/Contact";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <main className="min-h-screen">
      <Hero />
      <About />
      <Tracks />
      <Organizers />
      <ImportantDates />
      <Keynotes />
      <Publishing />
      <Committee />
      <Auth />
      <Contact />
      <Footer />
    </main>
  );
};

export default Index;
