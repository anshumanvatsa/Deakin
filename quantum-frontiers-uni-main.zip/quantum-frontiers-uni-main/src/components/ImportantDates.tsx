import { Calendar, Clock, CheckCircle2 } from "lucide-react";

const dates = [
  {
    event: "Paper Submission Opens",
    date: "Coming Soon",
    status: "upcoming"
  },
  {
    event: "Paper Submission Deadline",
    date: "TBA",
    status: "upcoming"
  },
  {
    event: "Notification of Acceptance",
    date: "TBA",
    status: "upcoming"
  },
  {
    event: "Camera-Ready Paper Submission",
    date: "TBA",
    status: "upcoming"
  },
  {
    event: "Early Bird Registration Deadline",
    date: "TBA",
    status: "upcoming"
  },
  {
    event: "Conference Dates",
    date: "June 2025",
    status: "upcoming"
  }
];

const ImportantDates = () => {
  return (
    <section className="py-20 px-4 bg-background">
      <div className="container mx-auto max-w-5xl">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-quantum bg-clip-text text-transparent mb-4">
            Important Dates
          </h2>
          <p className="text-muted-foreground text-lg">
            Mark your calendar for these key milestones
          </p>
          <div className="w-24 h-1 bg-gradient-quantum mx-auto rounded-full mt-4"></div>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical line */}
          <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-quantum hidden md:block"></div>

          <div className="space-y-6">
            {dates.map((item, index) => (
              <div
                key={index}
                className="relative flex items-start gap-6 animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {/* Timeline dot */}
                <div className="hidden md:flex w-16 h-16 bg-gradient-quantum rounded-full items-center justify-center flex-shrink-0 shadow-quantum z-10">
                  {item.status === "completed" ? (
                    <CheckCircle2 className="w-8 h-8 text-white" />
                  ) : (
                    <Clock className="w-8 h-8 text-white" />
                  )}
                </div>

                {/* Mobile dot */}
                <div className="md:hidden w-12 h-12 bg-gradient-quantum rounded-full flex items-center justify-center flex-shrink-0">
                  <Calendar className="w-6 h-6 text-white" />
                </div>

                {/* Content card */}
                <div className="flex-1 bg-card rounded-2xl p-6 shadow-card-hover border border-border hover:shadow-quantum transition-all duration-300 group">
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-foreground mb-2 group-hover:bg-gradient-quantum group-hover:bg-clip-text group-hover:text-transparent transition-all duration-300">
                        {item.event}
                      </h3>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-5 h-5 text-muted-foreground" />
                      <span className={`text-lg font-semibold ${
                        item.date === "Coming Soon" || item.date === "TBA" 
                          ? "text-primary" 
                          : "text-foreground"
                      }`}>
                        {item.date}
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Note */}
        <div className="mt-12 bg-gradient-card rounded-2xl p-6 border border-border text-center">
          <p className="text-muted-foreground">
            <span className="font-semibold text-foreground">📅 Stay Tuned:</span> Specific dates will be announced soon. 
            Subscribe to our newsletter to receive updates directly in your inbox.
          </p>
        </div>
      </div>
    </section>
  );
};

export default ImportantDates;
