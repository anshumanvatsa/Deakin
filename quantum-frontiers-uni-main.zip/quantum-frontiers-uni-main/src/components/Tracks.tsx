import { Cpu, Brain, Lock, Radio, Microchip, Network, Leaf, Globe } from "lucide-react";

const tracks = [
  {
    icon: Cpu,
    title: "Quantum Algorithms",
    description: "Advanced computational methods and optimization techniques in quantum systems"
  },
  {
    icon: Brain,
    title: "Quantum AI & ML",
    description: "Machine learning applications leveraging quantum computing power"
  },
  {
    icon: Lock,
    title: "Quantum Cryptography",
    description: "Secure communication protocols using quantum key distribution"
  },
  {
    icon: Radio,
    title: "Quantum Communication",
    description: "Next-generation communication systems and quantum internet"
  },
  {
    icon: Microchip,
    title: "Quantum Hardware",
    description: "Development of quantum processors, gates, and physical devices"
  },
  {
    icon: Network,
    title: "Quantum Networks",
    description: "Building quantum network infrastructure and entanglement distribution"
  },
  {
    icon: Leaf,
    title: "Sustainability Applications",
    description: "Quantum solutions for climate modeling and green technologies"
  },
  {
    icon: Globe,
    title: "Cross-Continental Research",
    description: "International collaboration and knowledge exchange initiatives"
  }
];

const Tracks = () => {
  return (
    <section className="py-20 px-4 bg-background">
      <div className="container mx-auto max-w-7xl">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-quantum bg-clip-text text-transparent mb-4">
            Conference Tracks
          </h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Explore cutting-edge research areas in quantum computing and emerging technologies
          </p>
          <div className="w-24 h-1 bg-gradient-quantum mx-auto rounded-full mt-4"></div>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {tracks.map((track, index) => {
            const Icon = track.icon;
            return (
              <div
                key={index}
                className="group relative bg-card rounded-2xl p-6 shadow-card-hover border border-border hover:shadow-quantum transition-all duration-300 hover:-translate-y-2 animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {/* Gradient overlay on hover */}
                <div className="absolute inset-0 bg-gradient-card rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                
                <div className="relative z-10">
                  {/* Icon */}
                  <div className="w-14 h-14 bg-gradient-quantum rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300">
                    <Icon className="w-7 h-7 text-white" />
                  </div>
                  
                  {/* Content */}
                  <h3 className="text-xl font-semibold mb-3 text-foreground">
                    {track.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {track.description}
                  </p>
                </div>

                {/* Corner accent */}
                <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-quantum opacity-5 rounded-bl-full"></div>
              </div>
            );
          })}
        </div>

        {/* Call to Action */}
        <div className="mt-16 text-center bg-gradient-card rounded-3xl p-8 border border-border">
          <h3 className="text-2xl font-semibold mb-4 text-foreground">
            Ready to Submit Your Research?
          </h3>
          <p className="text-muted-foreground mb-6 max-w-2xl mx-auto">
            Join leading researchers from around the world. Submit your paper and be part of advancing quantum frontiers.
          </p>
          <button className="bg-gradient-quantum text-white px-8 py-3 rounded-full font-semibold hover:shadow-quantum transition-all duration-300 transform hover:scale-105">
            Submit Paper
          </button>
        </div>
      </div>
    </section>
  );
};

export default Tracks;
