import { CheckCircle2 } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const committees = {
  general: [
    { name: "Dr. [Name TBA]", designation: "Chancellor", affiliation: "VIT Chennai" },
    { name: "Dr. [Name TBA]", designation: "Vice-Chancellor", affiliation: "Deakin University" },
    { name: "Dr. [Name TBA]", designation: "Director", affiliation: "VIT Chennai" },
    { name: "Dr. [Name TBA]", designation: "Director", affiliation: "Deakin University" }
  ],
  organizing: [
    { name: "Dr. [Name TBA]", designation: "Dean", affiliation: "VIT Chennai" },
    { name: "Dr. [Name TBA]", designation: "Associate Dean", affiliation: "Deakin University" },
    { name: "Dr. [Name TBA]", designation: "Deputy Dean", affiliation: "VIT Chennai" },
    { name: "Dr. [Name TBA]", designation: "Head of Department", affiliation: "Deakin University" }
  ],
  program: [
    { name: "Dr. [Name TBA]", designation: "Program Chair", affiliation: "VIT Chennai" },
    { name: "Dr. [Name TBA]", designation: "Program Co-Chair", affiliation: "Deakin University" },
    { name: "Dr. [Name TBA]", designation: "Technical Chair", affiliation: "VIT Chennai" },
    { name: "Dr. [Name TBA]", designation: "Technical Co-Chair", affiliation: "Deakin University" }
  ],
  programOrganizing: [
    { name: "Dr. [Name TBA]", designation: "Organizing Chair", affiliation: "VIT Chennai" },
    { name: "Dr. [Name TBA]", designation: "Organizing Co-Chair", affiliation: "Deakin University" },
    { name: "Dr. [Name TBA]", designation: "Coordinator", affiliation: "VIT Chennai" },
    { name: "Dr. [Name TBA]", designation: "Coordinator", affiliation: "Deakin University" }
  ],
  advisory: [
    { name: "Dr. [Name TBA]", designation: "Advisory Board Member", affiliation: "VIT Chennai" },
    { name: "Dr. [Name TBA]", designation: "Advisory Board Member", affiliation: "Deakin University" },
    { name: "Dr. [Name TBA]", designation: "International Advisor", affiliation: "VIT Chennai" },
    { name: "Dr. [Name TBA]", designation: "International Advisor", affiliation: "Deakin University" }
  ]
};

const Committee = () => {
  return (
    <section className="py-20 px-4 bg-gradient-to-b from-background via-purple-50/20 to-background dark:from-background dark:via-purple-900/10 dark:to-background">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-quantum bg-clip-text text-transparent mb-4">
            Conference Committee
          </h2>
          <p className="text-muted-foreground text-lg">
            Distinguished members leading Quantum Frontiers 2025
          </p>
          <div className="w-24 h-1 bg-gradient-quantum mx-auto rounded-full mt-4"></div>
        </div>

        <Tabs defaultValue="general" className="w-full">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 mb-8 bg-card/50 backdrop-blur-sm border border-border/50">
            <TabsTrigger value="general" className="data-[state=active]:bg-gradient-quantum data-[state=active]:text-white">
              General Committee
            </TabsTrigger>
            <TabsTrigger value="programOrganizing" className="data-[state=active]:bg-gradient-quantum data-[state=active]:text-white">
              Program Organizing
            </TabsTrigger>
            <TabsTrigger value="program" className="data-[state=active]:bg-gradient-quantum data-[state=active]:text-white">
              Program Committee
            </TabsTrigger>
            <TabsTrigger value="organizing" className="data-[state=active]:bg-gradient-quantum data-[state=active]:text-white">
              Organizing Committee
            </TabsTrigger>
            <TabsTrigger value="advisory" className="data-[state=active]:bg-gradient-quantum data-[state=active]:text-white">
              Advisory Committee
            </TabsTrigger>
          </TabsList>

          {Object.entries(committees).map(([key, members]) => (
            <TabsContent 
              key={key} 
              value={key} 
              className="animate-fade-in"
            >
              <div className="grid md:grid-cols-2 gap-6">
                {members.map((member, index) => (
                  <div
                    key={index}
                    className="group bg-card/80 backdrop-blur-sm rounded-2xl p-6 border border-border/50 hover:shadow-quantum transition-all duration-300 hover:-translate-y-1"
                    style={{ animationDelay: `${index * 0.1}s` }}
                  >
                    <div className="flex items-start gap-4">
                      <CheckCircle2 className="w-6 h-6 text-primary flex-shrink-0 mt-1 group-hover:scale-110 transition-transform" />
                      <div className="flex-1">
                        <h3 className="text-xl font-bold bg-gradient-quantum bg-clip-text text-transparent mb-2">
                          {member.name}
                        </h3>
                        <p className="text-foreground font-semibold mb-1">
                          {member.designation}
                        </p>
                        <p className="text-muted-foreground text-sm">
                          {member.affiliation}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </TabsContent>
          ))}
        </Tabs>
      </div>
    </section>
  );
};

export default Committee;
