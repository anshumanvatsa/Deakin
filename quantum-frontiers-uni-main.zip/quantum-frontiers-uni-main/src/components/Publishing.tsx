import { BookOpen, Award, TrendingUp } from "lucide-react";

const Publishing = () => {
  return (
    <section className="py-20 px-4 bg-background">
      <div className="container mx-auto max-w-6xl">
        <div className="text-center mb-16 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-quantum bg-clip-text text-transparent mb-4">
            Publishing & Indexing
          </h2>
          <p className="text-muted-foreground text-lg">
            Your research will reach a global audience
          </p>
          <div className="w-24 h-1 bg-gradient-quantum mx-auto rounded-full mt-4"></div>
        </div>

        {/* Main Publishing Card */}
        <div className="bg-gradient-to-br from-card to-card/50 rounded-3xl p-12 shadow-quantum border border-border mb-12 relative overflow-hidden">
          {/* Decorative background */}
          <div className="absolute inset-0 bg-gradient-card opacity-30"></div>
          
          <div className="relative z-10">
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="w-32 h-32 bg-gradient-quantum rounded-2xl flex items-center justify-center flex-shrink-0">
                <BookOpen className="w-16 h-16 text-white" />
              </div>
              
              <div className="flex-1 text-center md:text-left">
                <h3 className="text-3xl font-bold text-foreground mb-4">
                  Springer CCIS Proceedings
                </h3>
                <p className="text-lg text-muted-foreground mb-4">
                  All accepted and presented papers will be published in{" "}
                  <span className="font-semibold text-foreground">
                    Springer's Communications in Computer and Information Science (CCIS)
                  </span>{" "}
                  series, ensuring wide visibility and academic recognition.
                </p>
                <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full font-semibold">
                  <Award className="w-5 h-5" />
                  <span>SCOPUS Indexed</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Benefits Grid */}
        <div className="grid md:grid-cols-3 gap-6">
          {[
            {
              icon: Award,
              title: "SCOPUS Indexing",
              description: "Papers indexed in SCOPUS database, ensuring maximum visibility and citations in the academic community"
            },
            {
              icon: TrendingUp,
              title: "Global Reach",
              description: "Springer's international distribution network provides access to researchers worldwide"
            },
            {
              icon: BookOpen,
              title: "Quality Assurance",
              description: "Rigorous peer review process maintaining high academic standards and research quality"
            }
          ].map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <div
                key={index}
                className="bg-card rounded-2xl p-6 border border-border hover:shadow-quantum transition-all duration-300 animate-fade-in"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                <div className="w-14 h-14 bg-gradient-quantum rounded-xl flex items-center justify-center mb-4">
                  <Icon className="w-7 h-7 text-white" />
                </div>
                <h4 className="text-xl font-semibold text-foreground mb-3">
                  {benefit.title}
                </h4>
                <p className="text-muted-foreground text-sm leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Additional Info */}
        <div className="mt-12 bg-gradient-card rounded-2xl p-6 border border-border">
          <p className="text-muted-foreground text-center">
            <span className="font-semibold text-foreground">📚 Note:</span> Selected high-quality papers may be invited 
            for extended versions in premium journals. Authors will be notified after the review process.
          </p>
        </div>
      </div>
    </section>
  );
};

export default Publishing;
